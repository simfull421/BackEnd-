// db �� ȣ��
module.exports = {
    AiDB: require('./models/AiDB'),
    Tag: require('./models/Tag'),
    User: require('./models/User'),
    AdminQuiz: require('./models/AdminQuiz'),
    UserQuiz: require('./models/UserQuiz'),
    QuizProgress: require('./models/QuizProgress'),
    Notification: require('./models/Notification'),
    Comment: require('./models/Comment'),
    CommunityPost: require('./models/CommunityPost'),
    ITNews: require('./models/ITNews'),
    LearningUnit: require('./models/LearningUnit'),
    LearningSubUnit: require('./models/LearningSubUnit'),
    LearningProgress: require('./models/LearningProgress')
};