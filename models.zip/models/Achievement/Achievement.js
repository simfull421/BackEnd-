const mongoose = require("mongoose");

const AchievementSchema = new mongoose.Schema({
  achievementID: {
    type: String,
    required: true,
    unique: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  languageType: {
    type: String,
    enum: ["Git", "JS", "Node"],
  },
  image: {
    type: String, // URL �Ǵ� ��η� ó��
  },
  conditionType: {
    type: String,
    enum: [
      "���� �ذ�Ϸ�",
      "���� ���ذ�",
      "��Ÿ"
    ],
  },
  conditionValue: {
    type: Number,
  },
  reward: {
    type: String, // ��: "��� ����"
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Achievement", AchievementSchema);
