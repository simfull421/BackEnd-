const mongoose = require("mongoose");

const LearningMaterialSchema = new mongoose.Schema({
    learningMaterialID: {
        type: String,
        required: true,
        unique: true,
    },
    materialType: {
        type: String,
        enum: ["videos", "document"],
    },
    description: {
        type: String,
    },
    filePath: {
        type: String, // ��: "/learningMaterials/git_intro.pdf"
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    uploadedAt: {
        type: Date,
    },
});

module.exports = mongoose.model("LearningMaterial", LearningMaterialSchema);
