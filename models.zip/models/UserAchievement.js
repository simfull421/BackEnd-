const mongoose = require("mongoose");

const UserAchievementSchema = new mongoose.Schema({
    userAchievementID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        required: true,
        ref: "User",
    },
    achievementID: {
        type: String,
        required: true,
        ref: "Achievement",
    },
    isAchieved: {
        type: Boolean,
        default: false,
    },
    dateAchieved: {
        type: Date,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model("UserAchievement", UserAchievementSchema);
