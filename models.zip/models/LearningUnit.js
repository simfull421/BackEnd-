const mongoose = require('mongoose');
// LearningUnitDB
const LearningUnitSchema = new mongoose.Schema({
    unitId: { type: String, required: true },
    unitName: { type: String, required: true },
    unitDescription: { type: String, required: true },
    status: { type: String, enum: ["�Ϸ�", "���� ��", "�̿Ϸ�"], required: true }
});
const LearningUnit = mongoose.model('LearningUnit', LearningUnitSchema);
