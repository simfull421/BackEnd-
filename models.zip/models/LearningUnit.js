const mongoose = require("mongoose");

const LearningUnitSchema = new mongoose.Schema({
    unitID: {
        type: String,
        required: true,
        unique: true,
    },
    unitTitle: {
        type: String,
        required: true,
    },
    unitDescription: {
        type: String,
    },
    languageType: {
        type: String,
        enum: ["Git", "JS", "Node"],
    },
});

module.exports = mongoose.model("LearningUnit", LearningUnitSchema);
