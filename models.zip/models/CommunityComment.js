const mongoose = require("mongoose");

const CommunityCommentSchema = new mongoose.Schema({
  communityCommentID: {
    type: String,
    required: true,
    unique: true,
  },
  communityPostID: {
    type: String,
    ref: "CommunityPost",
    required: true,
  },
  userID: {
    type: String,
    ref: "User",
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  dateCreated: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("CommunityComment", CommunityCommentSchema);
