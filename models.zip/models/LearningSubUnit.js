const mongoose = require('mongoose');

// LearningSubUnitDB
const LearningSubUnitSchema = new mongoose.Schema({
    subUnitId: { type: String, required: true },
    subUnitName: { type: String, required: true },
    subUnitDescription: { type: String, required: true },
    status: { type: String, enum: ["�Ϸ�", "���� ��", "�̿Ϸ�"], required: true }
});
const LearningSubUnit = mongoose.model('LearningSubUnit', LearningSubUnitSchema);
