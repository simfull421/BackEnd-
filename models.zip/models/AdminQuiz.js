const mongoose = require('mongoose');
// AdminQuizDB
const AdminQuizSchema = new mongoose.Schema({
    adminId: { type: String, required: true },
    quizData: { type: Object, required: true }
});
const AdminQuiz = mongoose.model('AdminQuiz', AdminQuizSchema);