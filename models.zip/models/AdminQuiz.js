const mongoose = require("mongoose");

const AdminQuizSchema = new mongoose.Schema({
    adminQuizID: {
        type: String,
        required: true,
        unique: true,
    },
    adminQuizStatusID: {
        type: String,
        enum: ["�ذ�Ϸ�", "���ذ�"],
        required: true,
    },
    adminID: {
        type: String,
        ref: "Admin",
        required: true,
    },
    userQuizAnswerID: {
        type: String,
        ref: "UserQuizAnswer",
    },
    bookmarkID: {
        type: Number,
        ref: "Bookmark",
    },
    correctAnswer: {
        type: String,
        enum: ["Correct", "Incorrect"],
    },
    title: {
        type: String,
    },
    description: {
        type: String,
    },
    quizType: {
        type: String,
        enum: ["�ܴ�", "��������", "�ǽ�"],
    },
    category: {
        type: String,
        enum: ["node.js", "git", "����� ����"], // �ʿ� �� �߰� ����
    },
});

module.exports = mongoose.model("AdminQuiz", AdminQuizSchema);
