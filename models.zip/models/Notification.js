const mongoose = require("mongoose");

const NotificationSchema = new mongoose.Schema({
    notificationID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    commentID: {
        type: String,
        required: false,
    },
    commentModel: {
        type: String,
        enum: ["CommunityComment", "QuizComment"],
        required: function () {
            return !!this.commentID;
        },
    },
    quizID: {
        type: String,
        required: false,
    },
    quizModel: {
        type: String,
        enum: ["UserQuiz", "AdminQuiz"],
        required: function () {
            return !!this.quizID;
        },
    },
    message: {
        type: String,
        required: true,
    },
    isRead: {
        type: Boolean,
        default: false,
    },
    dateCreated: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("Notification", NotificationSchema);
