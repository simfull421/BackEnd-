const mongoose = require('mongoose');
// NotificationDB
const NotificationSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    notifications: { type: Map, of: Array }
});
const Notification = mongoose.model('Notification', NotificationSchema);
