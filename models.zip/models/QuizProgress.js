const mongoose = require('mongoose');
// QuizProgressDB
const QuizProgressSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    quizProgressData: { type: Map, of: Object }
});
const QuizProgress = mongoose.model('QuizProgress', QuizProgressSchema);
