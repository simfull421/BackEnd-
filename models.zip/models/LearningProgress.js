const mongoose = require('mongoose');
// LearningProgressDB
const LearningProgressSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    userProgressData: { type: Map, of: Object }
});
const LearningProgress = mongoose.model('LearningProgress', LearningProgressSchema);

module.exports = {
    Tag, User, AdminQuiz, UserQuiz, QuizProgress, Notification, Comment,
    CommunityPost, ITNews, LearningUnit, LearningSubUnit, LearningProgress
};