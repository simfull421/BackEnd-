const mongoose = require("mongoose");

const QuizCommentSchema = new mongoose.Schema({
    quizCommentID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    quizID: {
        type: String,
        required: true,
    },
    quizType: {
        type: String,
        enum: ["UserQuiz", "AdminQuiz"],
        required: true,
    },
    userQuizComment: {
        type: String,
        default: "",
    },
    dateCreated: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("QuizComment", QuizCommentSchema);
