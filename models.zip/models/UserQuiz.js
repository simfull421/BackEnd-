const mongoose = require('mongoose');
// UserQuizDB
const UserQuizSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    quizData: { type: Object, required: true }
});
const UserQuiz = mongoose.model('UserQuiz', UserQuizSchema);
