const mongoose = require("mongoose");

const ITNewsSchema = new mongoose.Schema({
    newsID: {
        type: String,
        required: true,
        unique: true,
    },
    adminID: {
        type: String,
        required: true,
        ref: "Admin",
    },
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
    },
    url: {
        type: String,
        required: true,
    },
    tag: {
        type: String,
        enum: ["AI", "IT", "Security", "Programming", "Other"], // �ʿ信 ���� ���� ����
    },
    dateFetched: {
        type: Date,
        default: Date.now,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model("ITNews", ITNewsSchema);
