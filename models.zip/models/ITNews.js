const mongoose = require('mongoose');// ITNewsDB
const ITNewsSchema = new mongoose.Schema({
    articles: { type: Array, required: true }
});
const ITNews = mongoose.model('ITNews', ITNewsSchema);
