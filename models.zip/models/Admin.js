const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema({
    adminID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    adminPermissions: {
        type: [String],
        enum: ["����ڰ���", "�����ۼ�"],
        default: [],
    },
});

module.exports = mongoose.model("Admin", AdminSchema);
