const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema({
    adminID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    adminPermissions: {
        type: [String],
        enum: ['user_management', 'news_write'],
        default: [],
    },
});

module.exports = mongoose.models.Admin || mongoose.model("Admin", AdminSchema);
