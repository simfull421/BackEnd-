const mongoose = require("mongoose");

const AttachmentSchema = new mongoose.Schema({
    attachmentID: {
        type: String,
        required: true,
        unique: true,
    },
    communityPostID: {
        type: String,
        ref: "CommunityPost",
        required: true,
    },
    name: {
        type: String,
        required: true,
    },
    size: {
        type: Number, // ���� ũ�� (bytes)
    },
    uploadedAt: {
        type: Date,
        default: Date.now,
    },
    url: {
        type: String,
        required: true,
    },
});

module.exports = mongoose.model("Attachment", AttachmentSchema);
