const mongoose = require('mongoose');

const communityBoardSchema = new mongoose.Schema({
  commuBoardID: {
    type: String,
    required: true,
    unique: true // PK 역할
  },
  boardType: {
    type: String,
    required: true,
    enum: ['공지', 'JS', 'Git'] // enum 제약조건
  }
});

module.exports = mongoose.model('CommunityBoard', communityBoardSchema);
