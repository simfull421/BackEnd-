const mongoose = require('mongoose');

const communityPostSchema = new mongoose.Schema({
  commuPostID: {
    type: String,
    required: true,
    unique: true // PK 역할
  },
  commuBoardID: {
    type: String,
    required: true,
    ref: 'CommunityBoard' // FK 역할
  },
  userID: {
    type: String,
    required: true,
    ref: 'User' // FK 역할
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  dateCreated: {
    type: Date,
    default: Date.now
  },
  viewCount: {
    type: Number,
    default: 0
  },
  commentCount: {
    type: Number,
    default: 0
  }
});

module.exports = mongoose.model('CommunityPost', communityPostSchema);
