const mongoose = require("mongoose");

const CommunityPostSchema = new mongoose.Schema({
  commuPostID: {
    type: String,
    required: true,
    unique: true,
  },
  commuBoardID: {
    type: String,
    ref: "CommunityBoard",
    required: true,
  },
  userID: {
    type: String,
    ref: "User",
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  dateCreated: {
    type: Date,
    default: Date.now,
  },
  viewCount: {
    type: Number,
    default: 0,
  },
  commentCount: {
    type: Number,
    default: 0,
  },
});

module.exports = mongoose.model("CommunityPost", CommunityPostSchema);
