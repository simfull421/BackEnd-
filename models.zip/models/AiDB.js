const mongoose = require("mongoose");

const AIDBSchema = new mongoose.Schema({
    aidbID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    userAIAnswer: {
        type: String,
        required: true,
    },
    userAnswerAIRespond: {
        type: String,
        required: true,
    },
}, {
    timestamps: true, // createdAt, updatedAt �ڵ� ����
});

module.exports = mongoose.model("AIDB", AIDBSchema);
