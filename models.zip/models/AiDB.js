const mongoose = require('mongoose');

const AiConversationSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    conversationHistory: [
        {
            message: { type: String, required: true },
            sender: { type: String, enum: ['user', 'ai'], required: true },
            timestamp: { type: Date, default: Date.now }
        }
    ]
});

const AiDB = mongoose.model('AiDB', AiConversationSchema);

module.exports = AiDB;