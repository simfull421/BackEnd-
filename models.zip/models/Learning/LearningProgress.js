const mongoose = require("mongoose");

const LearningProgressSchema = new mongoose.Schema({
    progressID: {
        type: String,
        required: true,
        unique: true,
    },
    subUnitStatus: {
        type: String,
        enum: ["�Ϸ�", "���� ��", "�̿Ϸ�"],
        required: true,
    },
    userID: {
        type: String,
        required: true,
        ref: "User",
    },
    learningProgressStatus: {
        type: String,
        enum: ["�Ϸ�", "���� ��", "�̿Ϸ�"],
    },
    completedAt: {
        type: Date,
    },
});

module.exports = mongoose.model("LearningProgress", LearningProgressSchema);
