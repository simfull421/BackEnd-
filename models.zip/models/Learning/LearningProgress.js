﻿const mongoose = require("mongoose");

const LearningProgressSchema = new mongoose.Schema({
 
    learningMaterialID: {
        type: String,
        required: true,
        ref: "LearningMaterial",
    },
    subUnitStatus: {
        type: String,
        enum: ["완료", "진행 중", "미완료"],
        required: true,
    },
    userID: {
        type: String,
        required: true,
        ref: "User",
    },
    learningProgressStatus: {
        type: String,
        enum: ["완료", "진행 중", "미완료"],
    },
    completedAt: {
        type: Date,
    },
    // ✅ 영상 학습 전용 진행도 정보
    videoProgress: {
        currentTime: {
            type: Number, // 초
            default: 0,
        },
        totalDuration: {
            type: Number, // 초
        },
        progressPercent: {
            type: Number, // 0 ~ 100
        },
    },
});

module.exports = mongoose.model("LearningProgress", LearningProgressSchema);
