const mongoose = require("mongoose");

const LearningSubUnitSchema = new mongoose.Schema({
    subUnitID: {
        type: String,
        required: true,
    },
    subUnitStatus: {
        type: String,
        required: true,
        enum: ["완료", "진행 중", "미완료"],
    },
    learningMaterialID: {
        type: String,
        required: true,
        ref: "LearningMaterial", 
    },
    subUnitTitle: {
        type: String,
        required: true,
    },
    subUnitDescription: {
        type: String,
    },
    languageType: {
        type: String,
        enum: ["Git", "JS", "Node"],
    },
});


LearningSubUnitSchema.index({ subUnitID: 1, subUnitStatus: 1 }, { unique: true });

module.exports = mongoose.model("LearningSubUnit", LearningSubUnitSchema);
