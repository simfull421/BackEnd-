const mongoose = require("mongoose");

const LearningSubUnitSchema = new mongoose.Schema({
    subUnitID: {
        type: String,
        required: true,
    },
    subUnitStatus: {
        type: String,
        required: true,
        enum: ["�Ϸ�", "���� ��", "�̿Ϸ�"],
    },
    learningMaterialID: {
        type: String,
        required: true,
        ref: "LearningMaterial", // ���� �н� �ڷ� ��
    },
    subUnitTitle: {
        type: String,
        required: true,
    },
    subUnitDescription: {
        type: String,
    },
    languageType: {
        type: String,
        enum: ["Git", "JS", "Node"],
    },
});

// ���� Ű ������ �ϴ� unique �ε��� ����
LearningSubUnitSchema.index({ subUnitID: 1, subUnitStatus: 1 }, { unique: true });

module.exports = mongoose.model("LearningSubUnit", LearningSubUnitSchema);
