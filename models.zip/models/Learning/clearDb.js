// clearDb.js (Node.js 프로젝트 폴더 안에 생성)
//node clearDb.js
const mongoose = require('mongoose');
// 초기화하려는 모델 파일 경로를 프로젝트 구조에 맞게 수정하세요.
// 여기서는 LearningMaterial 컬렉션을 비운다고 가정합니다.
const LearningMaterial = require('./LearningMaterial'); // 모델 임포트 (populateDb.js와 경로 동일)

// ✅ 자신의 MongoDB 연결 스트링으로 변경하세요!
const dbUri = 'mongodb://localhost:27017/lastProject'; // 예: 'mongodb://localhost:27017/lastProject'

async function clearLearningMaterials() {
  console.log('데이터베이스 연결 시도...');
  try {
    await mongoose.connect(dbUri, {
      // useNewUrlParser: true, // Mongoose 버전에 따라 제거 가능
      // useUnifiedTopology: true, // Mongoose 버전에 따라 제거 가능
      // 필요한 경우 다른 연결 옵션 추가
    });
    console.log('데이터베이스 연결 성공');

    console.log('LearningMaterial 컬렉션 초기화 시작...');
    // ✅ deleteMany({}): LearningMaterial 컬렉션의 모든 문서를 삭제합니다.
    const result = await LearningMaterial.deleteMany({});

    console.log(`✅ LearningMaterial 컬렉션 초기화 완료. 삭제된 문서 수: ${result.deletedCount}`);

  } catch (error) {
    console.error('❌ 데이터베이스 작업 중 오류 발생:', error);
    // 오류 로깅 개선
    if (error.message) {
      console.error('오류 메시지:', error.message);
    } else {
      console.error('일반 오류:', error);
    }
  } finally {
    console.log('데이터베이스 연결 종료 시도...');
    await mongoose.disconnect();
    console.log('데이터베이스 연결 종료.');
  }
}

// 함수 실행
clearLearningMaterials();