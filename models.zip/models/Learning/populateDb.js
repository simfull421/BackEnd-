// populateDb.js (Node.js 프로젝트 폴더 안에 생성)

const mongoose = require('mongoose');
// LearningMaterial 모델 파일 경로를 프로젝트 구조에 맞게 수정하세요.
// 예: 만약 모델 파일이 'node_project_root/models/LearningMaterial.js' 에 있다면 아래 경로는 './models/LearningMaterial' 입니다.
const LearningMaterial = require('./LearningMaterial');

// ✅ 자신의 MongoDB 연결 스트링으로 변경하세요!
const dbUri = 'mongodb://localhost:27017/lastProject'; // 예: 'mongodb://localhost:27017/your_db_name'

// 데이터베이스에 삽입할 학습 자료 목록 (배열 형태)
// 각 객체가 LearningMaterial 스키마의 필드와 일치해야 합니다.
const learningMaterialsData = [
    // --- Node.js 토픽 영상들 ---
    {
        learningMaterialID: '1장 Node.js 개요', // 이 영상의 고유 ID
        topic: 'node', // 어떤 토픽(강의)에 속하는지
        title: 'Node.js 개발 환경 설정', // 영상 제목 (프론트엔드 표시용)
        materialType: 'videos',
        // filePath는 서버의 public 폴더를 기준으로 하는 상대 경로입니다.
        // 만약 public/videos/node/ 에 영상이 있다면 '/videos/node/영상파일명.mp4' 형태가 됩니다.
        filePath: '/videos/node/1장.mp4', // 실제 영상 파일 경로
        // createdAt 필드는 기본값으로 자동 설정되므로 여기서 명시할 필요는 없습니다.
    },
    {
        learningMaterialID: '2장 파일 시스템 1',
        topic: 'node',
        title: 'Node.js 기본 모듈 사용법',
        materialType: 'videos',
        filePath: '/videos/node/2장 1.mp4',
    },
    {
        learningMaterialID: '2장 파일 시스템 2',
        topic: 'node',
        title: 'Node.js 기본 모듈 사용법',
        materialType: 'videos',
        filePath: '/videos/node/2장 2.mp4',
    },
    {
        learningMaterialID: '3장 간단한 HTTP 서버만들기 1',
        topic: 'node',
        title: 'express 이용한 http 서버 만들기',
        materialType: 'videos',
        filePath: '/videos/node/3장.mp4',
    },
    {
        learningMaterialID: '4장 Express.js 기본 1',
        topic: 'node',
        title: 'express 기본',
        materialType: 'videos',
        filePath: '/videos/node/4장 1.mp4',
    },
    {
        learningMaterialID: '4장 Express.js 기본 2',
        topic: 'node',
        title: 'express 기본',
        materialType: 'videos',
        filePath: '/videos/node/4장 2.mp4',
    },
    {
        learningMaterialID: '5장 ES6 문법',
        topic: 'node',
        title: 'ES6 문법',
        materialType: 'videos',
        filePath: '/videos/node/5장.mp4',
    },
  ];

    // 데이터베이스 연결 및 데이터 삽입 함수
    async function populateDb() {
        console.log('데이터베이스 연결 시도...');
        try {
            await mongoose.connect(dbUri, {
               
                // 필요한 경우 다른 연결 옵션 추가
            });
            console.log('데이터베이스 연결 성공');

            console.log('학습 자료 데이터 삽입 시작...');

            // 기존 데이터 중복 방지를 위해 learningMaterialID 기준으로 이미 있는 것은 건너뜁니다.
            // insertMany의 ordered: false 옵션은 오류 발생 시 멈추지 않고 계속 진행하게 합니다.
            // insertMany 반환 값에서 성공/실패 건수를 확인할 수 있습니다.
            const result = await LearningMaterial.insertMany(learningMaterialsData, { ordered: false });
            console.log(`✅ 성공적으로 삽입된 새 자료 수: ${result.length}`);

        } catch (error) {
            console.error('❌ 데이터베이스 작업 중 오류 발생:', error);
            // 중복 키 오류(11000)는 insertMany의 ordered: false 로 처리되지만,
            // 명시적으로 메시지를 찍어주거나 다른 오류를 구분할 수 있습니다.
            if (error.writeErrors) {
                error.writeErrors.forEach(writeError => {
                    if (writeError.code === 11000) {
                        console.warn(`⚠️ 경고: learningMaterialID '${writeError.op.learningMaterialID}'는 이미 존재합니다. 이 문서는 건너뜁니다.`);
                    } else {
                        console.error('다른 쓰기 오류:', writeError);
                    }
                });
            } else {
                console.error('일반 오류:', error);
            }
        } finally {
            console.log('데이터베이스 연결 종료 시도...');
            await mongoose.disconnect();
            console.log('데이터베이스 연결 종료.');
        }
    }

// 함수 실행
populateDb();
