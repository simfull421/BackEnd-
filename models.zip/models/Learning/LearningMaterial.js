const mongoose = require("mongoose");

const LearningMaterialSchema = new mongoose.Schema({
    learningMaterialID: {
        type: String,
        required: true,
        unique: true,
    },
    // ✅ NEW: 토픽(강의) ID 필드 추가
    topic: {
        type: String,
        required: true, // 어떤 토픽에 속하는지 필수 정보로
    },
    // ✅ NEW: 자료 제목 필드 추가 (프론트엔드 표시에 유용)
    title: {
        type: String,
        required: true, // 제목도 필수 정보로
    },
    materialType: {
        type: String,
        enum: ["videos", "document"], // 비디오인지 문서인지
        required: true, // 타입 필수
    },
    description: {
        type: String, // 자료에 대한 간단 설명 (선택 사항)
    },
    filePath: {
        type: String, // 서버의 public 폴더 기준 상대 경로
        required: true, // 파일 경로는 필수
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    uploadedAt: {
        type: Date, // (선택 사항)
    },
    // (필요하다면 해당 토픽 내에서의 순서를 나타내는 order 필드 등도 추가 가능)
    // order: { type: Number, default: 0 },
});

module.exports = mongoose.model("LearningMaterial", LearningMaterialSchema);