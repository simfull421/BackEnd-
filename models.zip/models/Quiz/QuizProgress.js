const mongoose = require("mongoose");

const QuizProgressSchema = new mongoose.Schema({
    quizProgressID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    adminQuizStatusID: {
        type: String,
        enum: ["�ذ�Ϸ�", "���ذ�"],
        required: false,
    },
    userQuizStatusID: {
        type: String,
        enum: ["�ذ�Ϸ�", "���ذ�"],
        required: false,
    },
    quizProgressStatus: {
        type: Number,
        min: 0.0,
        max: 1.0,
        required: true,
    },
});

module.exports = mongoose.model("QuizProgress", QuizProgressSchema);
