const mongoose = require("mongoose");

const UserQuizAnswerSchema = new mongoose.Schema({
    userQuizAnswerID: {
        type: String,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    userAnswerDescription: {
        type: String,
    },
});

module.exports = mongoose.model("UserQuizAnswer", UserQuizAnswerSchema);
