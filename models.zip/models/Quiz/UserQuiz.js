const mongoose = require("mongoose");

const UserQuizSchema = new mongoose.Schema({
    userQuizID: {
        type: String,
        required: true,
        unique: true,
    },
    userQuizStatusID: {
        type: String,
        enum: ["�ذ�Ϸ�", "���ذ�"],
        required: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    userQuizAnswerID: {
        type: String,
        ref: "UserQuizAnswer",
    },
    bookmarkID: {
        type: Number,
        ref: "Bookmark",
    },
    title: {
        type: String,
        required: true,
    },
    correctAnswer: {
        type: String,
        enum: ["Correct", "Incorrect"],
    },
    description: {
        type: String,
    },
    quizType: {
        type: String,
        enum: ["�ܴ�", "��������", "�ǽ�"],
    },
    category: {
        type: String,
        enum: ["node.js", "git"], // �ʿ� �� �ٸ� ī�װ��� �߰� ����
    },
});

module.exports = mongoose.model("UserQuiz", UserQuizSchema);
