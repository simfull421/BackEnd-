const mongoose = require("mongoose");

const BookmarkSchema = new mongoose.Schema({
    bookmarkID: {
        type: Number,
        required: true,
        unique: true,
    },
    userID: {
        type: String,
        ref: "User",
        required: true,
    },
    userQuizID: {
        type: String,
        ref: "UserQuiz",
    },
    adminQuizID: {
        type: String,
        ref: "AdminQuiz",
    },
});

module.exports = mongoose.model("Bookmark", BookmarkSchema);
