// lib/logic/video_player_logic.dart
import 'package:flutter/foundation.dart';
import 'package:front/services/api/progress_api.dart' as ProgressApi; // API 호출 함수

class VideoPlayerLogic {
  Future<bool> saveVideoProgressToBackend({
    required String progressId,
    required int currentTime,
    required int totalDuration,
    required int uiProgressPercent, // UI에 표시되던 진행률 %
    required bool markCompleted,
  }) async {
    final Map<String, dynamic> updateData = {
      "videoProgress": {
        "currentTime": currentTime,
        "totalDuration": totalDuration,
        "progressPercent": uiProgressPercent, // 이미 계산된 UI 진행률 사용
      },
    };

    if (markCompleted) {
      updateData["subUnitStatus"] = "완료";
      updateData["learningProgressStatus"] = "완료"; // 학습 단위 상태도 함께 업데이트
      updateData["completedAt"] = DateTime.now().toIso8601String();
      debugPrint('VideoPlayerLogic: 영상 완료로 DB에 저장 준비.');
    } else if (currentTime > 0) {
      // 영상이 완료되지 않았지만 재생 기록이 있는 경우 (시작 직후는 아님)
      updateData["subUnitStatus"] = "진행 중";
      updateData["learningProgressStatus"] = "진행 중";
      debugPrint('VideoPlayerLogic: 영상 일부 시청으로 DB에 "진행 중" 저장 준비.');
    }
    // currentTime이 0이고 markCompleted가 false인 경우는 subUnitStatus를 보내지 않아
    // 백엔드에서 기존 상태를 유지하거나 기본값(예: "미완료")으로 처리할 수 있습니다.

    debugPrint('VideoPlayerLogic: API 호출. progressId: $progressId, data: $updateData');

    try {
      // 실제 API 호출
      final success = await ProgressApi.updateProgress(progressId, updateData);
      if (success) {
        debugPrint('VideoPlayerLogic: 진행 상태 저장 API 성공 (progressId: $progressId)');
        return true;
      } else {
        debugPrint('VideoPlayerLogic: 진행 상태 저장 API 실패 (progressId: $progressId)');
        return false;
      }
    } catch (e) {
      debugPrint('VideoPlayerLogic: API 호출 중 예외 발생: $e');
      return false;
    }
  }
}