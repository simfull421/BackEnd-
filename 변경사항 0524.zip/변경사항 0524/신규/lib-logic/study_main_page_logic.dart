// lib/logic/study_main_page_logic.dart

import 'package:front/services/api/progress_api.dart'; // API 함수 임포트
import 'package:front/models/learning_models.dart';   // 모델 임포트
import 'package:flutter/foundation.dart'; // print 대신 debugPrint 사용을 위해 (선택 사항)

class StudyMainPageLogic {
  // 이 클래스는 직접적인 UI 상태를 가지지 않습니다.
  // 대신, 데이터를 가져오고 처리하여 _StudyMainPageState에 전달합니다.

  Future<List<LearningMaterial>?> getCourseMaterials(String topicId) async {
    debugPrint('StudyMainPageLogic: 강의 자료 목록 로드 시작 (토픽: $topicId)');
    // 실제 API 호출 (progress_api.dart 에 정의된 함수)
    return await fetchCourseMaterials(topicId);
  }

  int findInitialMaterialIndex(List<LearningMaterial> materials, String? initialMaterialId) {
    int startIndex = 0;
    if (initialMaterialId != null) {
      final foundIdx = materials.indexWhere((m) => m.learningMaterialID == initialMaterialId);
      if (foundIdx != -1) {
        startIndex = foundIdx;
        debugPrint('StudyMainPageLogic: 이어보기 - 초기 학습 자료 ($initialMaterialId)를 인덱스 $startIndex 에서 찾았습니다.');
      } else {
        debugPrint('StudyMainPageLogic: 경고 - 이어보기 학습 자료 ID ($initialMaterialId)를 목록에서 찾지 못했습니다. 첫 번째 자료부터 시작합니다.');
      }
    }
    return startIndex;
  }

  Future<LearningProgress?> getMaterialProgress(String materialId) async {
    debugPrint('StudyMainPageLogic: 자료 진행도 로드/생성 시작 (자료 ID: $materialId)');
    LearningProgress? progress = await fetchProgressDetails(materialId);

    if (progress == null) {
      debugPrint('StudyMainPageLogic: 기존 진행도 없음. 새 진행도 생성 시도.');
      progress = await createProgress(materialId);
      if (progress != null) {
        debugPrint('StudyMainPageLogic: 새 진행도 생성 성공: ${progress.id}');
      }
    }

    if (progress == null) {
      debugPrint('StudyMainPageLogic: 최종적으로 진행도 정보를 가져오거나 생성하는 데 실패했습니다.');
    }
    return progress;
  }

  // UI 데이터 준비를 위한 헬퍼 메소드들
  String determineCurrentMaterialTitle(LearningMaterial? material) {
    if (material != null) {
      return material.title ?? material.learningMaterialID;
    }
    return '강의 제목 로딩 중...';
  }

  String determineVideoUrl(LearningMaterial? material) {
    // 실제 서버 주소 및 파일 경로 형식에 맞게 수정하세요.
    if (material != null && material.filePath != null && material.filePath!.isNotEmpty) {
      return 'http://localhost:3000${material.filePath}';
    }
    debugPrint("StudyMainPageLogic: 경고 - 현재 학습 자료에 filePath가 비어있거나 null입니다.");
    return '';
  }

  double determineInitialPlaybackTime(LearningProgress? currentProgress) {
    return currentProgress?.videoProgress?.currentTime?.toDouble() ?? 0.0;
  }
}