// Create a new file, e.g., models/topic_progress.dart

import 'dart:convert';

TopicProgressResponse topicProgressResponseFromJson(String str) =>
    TopicProgressResponse.fromJson(json.decode(str));

String topicProgressResponseToJson(TopicProgressResponse data) =>
    json.encode(data.toJson());

class TopicProgressResponse {
    final String topicId;
    final String userId;
    final int totalMaterials;
    final int completedMaterials;
    final int inProgressMaterials;
    final int notStartedMaterials;
    final double overallProgressPercent;
    final List<DetailedProgressItem> detailedProgress;
    final MaterialInfo? lastStoppedMaterial;
    final MaterialInfo? nextMaterialToWatch;

    TopicProgressResponse({
        required this.topicId,
        required this.userId,
        required this.totalMaterials,
        required this.completedMaterials,
        required this.inProgressMaterials,
        required this.notStartedMaterials,
        required this.overallProgressPercent,
        required this.detailedProgress,
        this.lastStoppedMaterial,
        this.nextMaterialToWatch,
    });

    factory TopicProgressResponse.fromJson(Map<String, dynamic> json) =>
        TopicProgressResponse(
            topicId: json["topicId"],
            userId: json["userId"],
            totalMaterials: json["totalMaterials"],
            completedMaterials: json["completedMaterials"],
            inProgressMaterials: json["inProgressMaterials"],
            notStartedMaterials: json["notStartedMaterials"],
            overallProgressPercent: (json["overallProgressPercent"] as num).toDouble(),
            detailedProgress: List<DetailedProgressItem>.from(
                json["detailedProgress"].map((x) => DetailedProgressItem.fromJson(x))),
            lastStoppedMaterial: json["lastStoppedMaterial"] == null
                ? null
                : MaterialInfo.fromJson(json["lastStoppedMaterial"]),
            nextMaterialToWatch: json["nextMaterialToWatch"] == null
                ? null
                : MaterialInfo.fromJson(json["nextMaterialToWatch"]),
        );

    Map<String, dynamic> toJson() => {
        "topicId": topicId,
        "userId": userId,
        "totalMaterials": totalMaterials,
        "completedMaterials": completedMaterials,
        "inProgressMaterials": inProgressMaterials,
        "notStartedMaterials": notStartedMaterials,
        "overallProgressPercent": overallProgressPercent,
        "detailedProgress": List<dynamic>.from(detailedProgress.map((x) => x.toJson())),
        "lastStoppedMaterial": lastStoppedMaterial?.toJson(),
        "nextMaterialToWatch": nextMaterialToWatch?.toJson(),
    };
}

class DetailedProgressItem {
    final String learningMaterialID;
    final String? title; // Make title nullable or ensure it's always there
    final String status;
    final VideoProgress videoProgress;

    DetailedProgressItem({
        required this.learningMaterialID,
        this.title,
        required this.status,
        required this.videoProgress,
    });

    factory DetailedProgressItem.fromJson(Map<String, dynamic> json) =>
        DetailedProgressItem(
            learningMaterialID: json["learningMaterialID"],
            title: json["title"],
            status: json["status"],
            videoProgress: VideoProgress.fromJson(json["videoProgress"]),
        );

    Map<String, dynamic> toJson() => {
        "learningMaterialID": learningMaterialID,
        "title": title,
        "status": status,
        "videoProgress": videoProgress.toJson(),
    };
}

class MaterialInfo {
    final String learningMaterialID;
    final String? title; // Make title nullable or ensure it's always there
    final String subUnitStatus;
    final VideoProgress videoProgress;

    MaterialInfo({
        required this.learningMaterialID,
        this.title,
        required this.subUnitStatus,
        required this.videoProgress,
    });

    factory MaterialInfo.fromJson(Map<String, dynamic> json) => MaterialInfo(
        learningMaterialID: json["learningMaterialID"],
        title: json["title"],
        subUnitStatus: json["subUnitStatus"],
        videoProgress: VideoProgress.fromJson(json["videoProgress"]),
    );

    Map<String, dynamic> toJson() => {
        "learningMaterialID": learningMaterialID,
        "title": title,
        "subUnitStatus": subUnitStatus,
        "videoProgress": videoProgress.toJson(),
    };
}

class VideoProgress {
    final num currentTime;
    final num? totalDuration;
    final num? progressPercent;

    VideoProgress({
        required this.currentTime,
        this.totalDuration,
        this.progressPercent,
    });

    factory VideoProgress.fromJson(Map<String, dynamic> json) => VideoProgress(
        currentTime: json["currentTime"] ?? 0,
        totalDuration: json["totalDuration"],
        progressPercent: json["progressPercent"],
    );

    Map<String, dynamic> toJson() => {
        "currentTime": currentTime,
        "totalDuration": totalDuration,
        "progressPercent": progressPercent,
    };
}