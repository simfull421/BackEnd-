// lib/models/learning_models.dart

// import 'package:flutter/material.dart'; // 현재 코드에서는 사용 안 함
// import 'dart:convert'; // 현재 코드에서는 사용 안 함

// Define a simple model/class to hold LearningProgress data
class LearningProgress {
  final String id;
  final String learningMaterialID;
  final String userID;
  final String subUnitStatus;
  final String learningProgressStatus;
  final DateTime? completedAt;
  final VideoProgress? videoProgress; // Uses VideoProgress model

  LearningProgress({
    required this.id,
    required this.learningMaterialID,
    required this.userID,
    required this.subUnitStatus,
    required this.learningProgressStatus,
    this.completedAt,
    this.videoProgress,
  });

  factory LearningProgress.fromJson(Map<String, dynamic> json) {
    return LearningProgress(
      id: json['_id'] as String,
      learningMaterialID: json['learningMaterialID'] as String,
      userID: json['userID'] as String,
      subUnitStatus: json['subUnitStatus'] as String,
      learningProgressStatus: json['learningProgressStatus'] as String,
      completedAt: json['completedAt'] != null ? DateTime.parse(json['completedAt'] as String) : null,
      videoProgress: json['videoProgress'] != null ? VideoProgress.fromJson(json['videoProgress'] as Map<String, dynamic>) : null,
    );
  }
}

// Define a simple model/class for VideoProgress
class VideoProgress {
  final int currentTime;
  final int? totalDuration;
  final int? progressPercent;

  VideoProgress({
    required this.currentTime,
    this.totalDuration,
    this.progressPercent,
  });

  factory VideoProgress.fromJson(Map<String, dynamic> json) {
    return VideoProgress(
      currentTime: (json['currentTime'] as num?)?.toInt() ?? 0,
      totalDuration: (json['totalDuration'] as num?)?.toInt(),
      progressPercent: (json['progressPercent'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() {
      return {
        'currentTime': currentTime,
        'totalDuration': totalDuration,
        'progressPercent': progressPercent,
      };
  }
}

// Define a simple model/class for LearningMaterial
class LearningMaterial {
  final String id; // This is the _id from MongoDB
  final String learningMaterialID; // Your custom ID
  final String? title; // ★★★ 필드 선언 위치로 이동, nullable로 변경 ★★★
  final String topic;
  final String materialType;
  final String filePath;
  final String? description;

  LearningMaterial({
    required this.id,
    required this.learningMaterialID,
    this.title, // ★★★ 생성자 파라미터 (필드와 연결) ★★★
    required this.topic,
    required this.materialType,
    required this.filePath,
    this.description,
  });

  factory LearningMaterial.fromJson(Map<String, dynamic> json) {
    return LearningMaterial(
      id: json['_id'] as String,
      learningMaterialID: json['learningMaterialID'] as String,
      title: json['title'] as String?, // ★★★ title 파싱 추가 ★★★
      topic: json['topic'] as String,
      materialType: json['materialType'] as String,
      filePath: json['filePath'] as String,
      description: json['description'] as String?,
    );
  }
}