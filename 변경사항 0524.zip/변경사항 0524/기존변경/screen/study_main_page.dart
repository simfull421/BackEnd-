// lib/screens/study_main_page.dart

import 'package:flutter/material.dart';
import 'package:front/services/api/progress_api.dart'; // 이 파일은 StudyMainPageLogic에서 사용되므로 여기서 직접 필요 없을 수 있음
import 'package:front/widgets/video_progress_player.dart';
import 'package:front/widgets/layout/study_main_layout.dart';
import 'package:front/screens/sidebar/study_right_sidebar.dart';
import 'package:front/models/learning_models.dart';
import 'package:front/screens/main_home_page.dart';
import 'package:front/logic/study_main_page_logic.dart'; // 방금 만든 로직 클래스 임포트

class StudyMainPage extends StatefulWidget {
  final String topicId;
  final String? initialMaterialId;

  const StudyMainPage({
    super.key,
    required this.topicId,
    this.initialMaterialId,
  });

  @override
  State<StudyMainPage> createState() => _StudyMainPageState();
}

class _StudyMainPageState extends State<StudyMainPage> {
  // UI 상태를 위한 변수들은 여전히 State 클래스가 가짐
  bool _isSidebarOpen = false;
  List<LearningMaterial> _learningMaterials = [];
  int _currentMaterialIndex = 0;
  LearningProgress? _currentProgress;
  bool _isLoading = true;

  late final StudyMainPageLogic _logic; // 로직 클래스 인스턴스

  @override
  void initState() {
    super.initState();
    _logic = StudyMainPageLogic(); // 로직 클래스 초기화
    _loadInitialData(); // 데이터 로딩 함수 호출
  }

  Future<void> _loadInitialData() async {
    if (!mounted) return;
    setState(() { _isLoading = true; });

    final materials = await _logic.getCourseMaterials(widget.topicId);

    if (materials != null && materials.isNotEmpty) {
      final startIndex = _logic.findInitialMaterialIndex(materials, widget.initialMaterialId);
      
      // 첫 번째 (또는 지정된) 자료의 진행도 로드
      final progressForInitialMaterial = await _logic.getMaterialProgress(materials[startIndex].learningMaterialID);

      if (mounted) {
        setState(() {
          _learningMaterials = materials;
          _currentMaterialIndex = startIndex;
          _currentProgress = progressForInitialMaterial;
          _isLoading = false;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          _learningMaterials = []; // 자료가 없을 경우 빈 리스트로 초기화
          _isLoading = false;
          debugPrint('_StudyMainPageState: 해당 토픽(${widget.topicId})의 학습 자료를 불러오는데 실패했거나 자료가 없습니다.');
        });
      }
    }
  }

  Future<void> _navigateToMaterial(int materialIndex) async {
    if (!mounted) return;
    setState(() {
      _isLoading = true; // 새 자료 로딩 시작
      _currentMaterialIndex = materialIndex;
      _currentProgress = null; // 이전 진행도 정보 초기화
    });

    final materialId = _learningMaterials[_currentMaterialIndex].learningMaterialID;
    final progress = await _logic.getMaterialProgress(materialId);

    if (mounted) {
      setState(() {
        _currentProgress = progress;
        _isLoading = false; // 로딩 완료
      });
    }
  }

  void _toggleSidebar() {
    setState(() {
      _isSidebarOpen = !_isSidebarOpen;
    });
  }

  void _goToPreviousUnit() {
    if (_currentMaterialIndex > 0 && _learningMaterials.isNotEmpty) {
      debugPrint("_StudyMainPageState: 이전 단원으로 이동");
      _navigateToMaterial(_currentMaterialIndex - 1);
    } else {
      debugPrint("_StudyMainPageState: 이전 단원 없음");
    }
  }

  void _goToNextUnit() {
    if (_currentMaterialIndex < _learningMaterials.length - 1 && _learningMaterials.isNotEmpty) {
      debugPrint("_StudyMainPageState: 다음 단원으로 이동");
      _navigateToMaterial(_currentMaterialIndex + 1);
    } else {
      debugPrint("_StudyMainPageState: 다음 단원 없음");
    }
  }

  @override
  Widget build(BuildContext context) {
    // 현재 상태에 따라 UI에 필요한 값들 계산
    LearningMaterial? currentMaterial;
    if (_learningMaterials.isNotEmpty && _currentMaterialIndex >= 0 && _currentMaterialIndex < _learningMaterials.length) {
      currentMaterial = _learningMaterials[_currentMaterialIndex];
    }

    final String currentTitle = _logic.determineCurrentMaterialTitle(currentMaterial);
    final String videoUrl = _logic.determineVideoUrl(currentMaterial);
    final double initialPlaybackTime = _logic.determineInitialPlaybackTime(_currentProgress);

    if (currentMaterial != null) {
         debugPrint('_StudyMainPageState build: 현재 비디오 URL: $videoUrl, 초기 재생 시간: $initialPlaybackTime 초, 현재 자료 제목: $currentTitle');
    }


    // 로딩 상태 및 데이터 유무에 따른 UI 분기
    if (_isLoading && _learningMaterials.isEmpty) { // 페이지 초기 전체 로딩
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_learningMaterials.isEmpty && !_isLoading) { // 자료 없음 (로딩 후)
      return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.home),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const MainHomePage()),
                (Route<dynamic> route) => false,
              );
            },
          ),
          title: const Text('학습'),
        ),
        body: const Center(child: Text('학습 자료를 불러올 수 없습니다.')),
      );
    }

    // 기본 UI 구성
    return Stack(
      children: [
        // 자료는 있는데 세부 진행도 로딩 중일 때 (예: 이전/다음 버튼 클릭 시)
        // 또는 currentProgress가 아직 로드 안됐을 때
        (_isLoading && _learningMaterials.isNotEmpty) || (_currentProgress == null && videoUrl.isNotEmpty && !_isLoading)
            ? const Center(child: CircularProgressIndicator())
            : (videoUrl.isNotEmpty) // _currentProgress가 null일 수 있으나 videoUrl이 있다면 플레이어는 표시 시도
                ? StudyMainLayout(
                    unitTitle: currentTitle,
                    videoContent: VideoProgressPlayer(
                      videoUrl: videoUrl,
                      // currentProgress가 null일 수 있으므로 currentProgress!.id 전에 null 체크 필요
                      // VideoProgressPlayer는 progressId가 필수이므로, currentProgress가 null이면 플레이어를 아예 안보여주거나
                      // 임시 ID를 전달하거나, currentProgress 로딩이 완료될 때까지 플레이어를 안보여줘야 함.
                      // 여기서는 _currentProgress가 null이어도 videoUrl이 있으면 플레이어를 표시하되, progressId가 문제될 수 있음.
                      // _currentProgress 로딩이 완료될 때까지 플레이어를 지연시키는 것이 안전.
                      // 위 로딩 조건에서 (_currentProgress == null && videoUrl.isNotEmpty && !_isLoading) 가 이 경우를 커버할 수 있음.
                      progressId: _currentProgress!.id, // currentProgress가 null이 아님을 보장해야 함.
                      initialPlaybackTime: initialPlaybackTime,
                    ),
                    onPrevious: (_currentMaterialIndex > 0 && _learningMaterials.isNotEmpty) ? _goToPreviousUnit : null,
                    onNext: (_currentMaterialIndex < _learningMaterials.length - 1 && _learningMaterials.isNotEmpty) ? _goToNextUnit : null,
                    onToggleSidebar: _toggleSidebar,
                    isSidebarOpen: _isSidebarOpen,
                    canGoPrevious: _currentMaterialIndex > 0 && _learningMaterials.isNotEmpty,
                    canGoNext: _currentMaterialIndex < _learningMaterials.length - 1 && _learningMaterials.isNotEmpty,
                    onGoHome: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => const MainHomePage()),
                        (Route<dynamic> route) => false,
                      );
                    },
                  )
                : Scaffold( // videoUrl이 비어있거나 currentProgress 로드 실패 등 최종 오류 상황
                    appBar: AppBar(
                      leading: IconButton(
                        icon: const Icon(Icons.home),
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => const MainHomePage()),
                            (Route<dynamic> route) => false,
                          );
                        },
                      ),
                      title: Text(currentTitle),
                    ),
                    body: const Center(child: Text('학습 콘텐츠를 표시할 수 없습니다. 비디오 정보가 올바르지 않거나 진행도 로드에 실패했습니다.')),
                  ),
        if (_isSidebarOpen)
          Positioned(
            right: 0,
            top: 0,
            bottom: 0,
            child: StudySidebar(onClose: _toggleSidebar),
          ),
      ],
    );
  }
}