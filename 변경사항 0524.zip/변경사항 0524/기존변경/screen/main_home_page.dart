// lib/screens/main_home_page.dart

import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http; // Logic 클래스에서 사용하므로 여기선 직접 필요 X
// import 'dart:convert'; // Logic 클래스에서 사용

import 'package:front/models/topic_progress.dart';
import 'package:front/screens/study_main_page.dart';
// import 'package:front/services/auth_storage.dart' as auth_storage; // Logic 클래스에서 사용
import 'package:front/logic/main_home_page_logic.dart'; // 새로 만든 Logic 클래스 임포트
import 'package:flutter/foundation.dart'; // debugPrint 사용


class MainHomePage extends StatefulWidget {
  const MainHomePage({Key? key}) : super(key: key);

  @override
  State<MainHomePage> createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  TopicProgressResponse? _nodeProgressData;
  TopicProgressResponse? _gitProgressData;
  bool _isLoading = true;
  String? _errorMessage;

  late MainHomePageLogic _logic; // Logic 클래스 인스턴스

  // final String _apiBaseUrl = 'http://localhost:3000'; // Logic 클래스로 이동

  @override
  void initState() {
    super.initState();
    _logic = MainHomePageLogic(); // Logic 클래스 초기화
    _fetchTopicsProgress();
  }

  // _getAuthToken 함수는 _logic.getAuthToken()으로 대체 가능
  // Future<String?> _getAuthToken() async {
  //   return await _logic.getAuthToken();
  // }

  Future<void> _fetchTopicsProgress() async {
    if (!mounted) return; // 비동기 작업 후 위젯이 unmounted 상태일 수 있으므로 체크
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    String? accumulatedErrorMessage; // 여러 API 호출에서 발생할 수 있는 에러 메시지 누적

    try {
      final String? token = await _logic.getAuthToken(); // Logic 클래스의 메소드 사용
      debugPrint('MainHomePage DEBUG: Fetched token: $token');

      if (token == null) {
        if (mounted) {
          setState(() {
            _errorMessage = "인증 토큰이 없습니다. 로그인 해주세요.";
            _isLoading = false;
          });
        }
        return;
      }

      // Node.js 진행도 요청
      final nodeResult = await _logic.fetchSingleTopicProgress('node', token);
      if (!mounted) return; // await 이후 mounted 체크
      
      if (nodeResult.isSuccessOrNotFoundWithDefaultData) {
        _nodeProgressData = nodeResult.data;
      } else {
        accumulatedErrorMessage = nodeResult.errorMessage;
      }

      // Git 진행도 요청
      final gitResult = await _logic.fetchSingleTopicProgress('git', token);
      if (!mounted) return; // await 이후 mounted 체크

      if (gitResult.isSuccessOrNotFoundWithDefaultData) {
        _gitProgressData = gitResult.data;
      } else {
        if (accumulatedErrorMessage == null) {
          accumulatedErrorMessage = gitResult.errorMessage;
        } else {
          accumulatedErrorMessage += '\n${gitResult.errorMessage}';
        }
      }

    } catch (e) { // _logic 메소드 호출 중 발생할 수 있는 최상위 예외 처리
      debugPrint('MainHomePage Error in _fetchTopicsProgress orchestration: $e');
      if (mounted) {
         accumulatedErrorMessage = (accumulatedErrorMessage ?? '') + '\n알 수 없는 오류 발생: $e';
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
          if (accumulatedErrorMessage != null) {
            _errorMessage = accumulatedErrorMessage;
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // build 메소드 내용은 대부분 동일하게 유지됩니다.
    // _nodeProgressData, _gitProgressData, _isLoading, _errorMessage 상태를 사용합니다.
    return LayoutBuilder(
      builder: (context, constraints) {
        double contentWidth = constraints.maxWidth;

        return Scaffold(
          backgroundColor: const Color(0xFFF5F6F8),
          body: RefreshIndicator(
            onRefresh: _fetchTopicsProgress,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Image.asset(
                      'images/main_head_img.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 24),
                  if (_isLoading)
                    const Center(child: CircularProgressIndicator())
                  else if (_errorMessage != null)
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.red, fontSize: 16),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 10),
                            ElevatedButton(
                                onPressed: _fetchTopicsProgress,
                                child: const Text("재시도"))
                          ],
                        ),
                      ),
                    )
                  else
                    _buildLearningProgressSection(contentWidth), // 학습 진행 카드 영역

                  const SizedBox(height: 32),
                  _buildInfoSection(contentWidth), // IT 뉴스, 커뮤니티 카드 영역
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildLearningProgressSection(double contentWidth) {
    // 이 메소드의 내용은 _nodeProgressData와 _gitProgressData를 사용하므로 거의 변경 없음
    // 다만, null일 경우에 대한 처리가 좀 더 명확해질 수 있습니다.
    // (MainHomePageLogic에서 404 시 기본값을 채워주므로 null 가능성은 줄어듦)

    String? nodeInitialMaterialId;
    if (_nodeProgressData != null) { // _nodeProgressData가 null이 아님을 보장 (기본값 객체 포함)
      if (_nodeProgressData!.lastStoppedMaterial != null &&
          _nodeProgressData!.lastStoppedMaterial!.subUnitStatus == "진행 중") {
        nodeInitialMaterialId = _nodeProgressData!.lastStoppedMaterial!.learningMaterialID;
      } else if (_nodeProgressData!.nextMaterialToWatch != null) {
        nodeInitialMaterialId = _nodeProgressData!.nextMaterialToWatch!.learningMaterialID;
      }
    }

    String? gitInitialMaterialId;
    if (_gitProgressData != null) { // _gitProgressData가 null이 아님을 보장
        if (_gitProgressData!.lastStoppedMaterial != null &&
            _gitProgressData!.lastStoppedMaterial!.subUnitStatus == "진행 중") {
        gitInitialMaterialId = _gitProgressData!.lastStoppedMaterial!.learningMaterialID;
        } else if (_gitProgressData!.nextMaterialToWatch != null) {
        gitInitialMaterialId = _gitProgressData!.nextMaterialToWatch!.learningMaterialID;
        }
    }

    String nodeCurrentUnit = _nodeProgressData?.nextMaterialToWatch?.title ??
        _nodeProgressData?.lastStoppedMaterial?.title ??
        (_nodeProgressData?.totalMaterials == 0 ? '학습 자료 없음' : '시작 전');
    String nodeLastTopic = _nodeProgressData?.lastStoppedMaterial?.title ?? '기록 없음';
    double nodeProgress = (_nodeProgressData?.overallProgressPercent ?? 0.0) / 100.0;

    String gitCurrentUnit = _gitProgressData?.nextMaterialToWatch?.title ??
        _gitProgressData?.lastStoppedMaterial?.title ??
        (_gitProgressData?.totalMaterials == 0 ? '학습 자료 없음' : '시작 전');
    String gitLastTopic = _gitProgressData?.lastStoppedMaterial?.title ?? '기록 없음';
    double gitProgress = (_gitProgressData?.overallProgressPercent ?? 0.0) / 100.0;

    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: contentWidth > 1000 ? contentWidth * 0.1 : 24.0,
      ),
      child: Flex(
        direction: contentWidth > 700 ? Axis.horizontal : Axis.vertical,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                // _nodeProgressData가 null이 아니고, totalMaterials가 0이 아닌 경우에만 이동
                if (_nodeProgressData != null && _nodeProgressData!.totalMaterials > 0) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StudyMainPage(
                        topicId: 'node',
                        initialMaterialId: nodeInitialMaterialId,
                      ),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Node.js 학습 자료가 아직 없습니다.')),
                  );
                }
              },
              child: _buildStudyCard(
                title: 'Node.js',
                currentUnit: nodeCurrentUnit,
                lastTopic: nodeLastTopic,
                progress: nodeProgress,
                levels: const ['JS', 'DOM', 'Node JS'],
              ),
            ),
          ),
          SizedBox(width: contentWidth > 700 ? 16 : 0, height: contentWidth <= 700 ? 16 : 0),
          Expanded(
            child: GestureDetector(
              onTap: () {
                 if (_gitProgressData != null && _gitProgressData!.totalMaterials > 0) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StudyMainPage(
                        topicId: 'git',
                        initialMaterialId: gitInitialMaterialId,
                      ),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Git 학습 자료가 아직 없습니다.')),
                  );
                }
              },
              child: _buildStudyCard(
                title: 'Git',
                currentUnit: gitCurrentUnit,
                lastTopic: gitLastTopic,
                progress: gitProgress,
                levels: const ['기초', '중급', '고급'],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // _buildInfoSection, _buildStudyCard, _buildListCard 메소드는 기존과 동일하게 유지
  // ... (기존 _buildInfoSection 코드)
  Widget _buildInfoSection(double contentWidth) {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: contentWidth > 1000 ? contentWidth * 0.1 : 24.0,
      ),
      child: Flex(
        direction: contentWidth > 700 ? Axis.horizontal : Axis.vertical,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: _buildListCard(
              title: 'IT News',
              items: const [
                '2025 웹 트렌드는? - 2025-01-10',
                '2025 UI 트렌드는? - 2025-01-10',
                '프론트엔드 숙지 사항 - 2025-01-10',
                '2024 웹 트렌드는? - 2025-01-10',
              ],
              onMoreTapComment: 'IT 뉴스 연결',
            ),
          ),
          SizedBox(width: contentWidth > 700 ? 16 : 0, height: contentWidth <= 700 ? 16 : 0),
          Expanded(
            child: _buildListCard(
              title: '커뮤니티',
              items: const [
                'JavaScript의 비동기 처리, Asy... - 2025-01-10',
                'JavaScript로 DOM 조작을 할 때 ... - 2025-01-10',
                'forEach와 map의 차이점은 무엇? - 2025-01-10',
                '이벤트 위임은 왜 사용하는 걸까요? - 2025-01-10',
              ],
              onMoreTapComment: '커뮤니티 연결',
            ),
          ),
        ],
      ),
    );
  }

  // ... (기존 _buildStudyCard 코드)
  Widget _buildStudyCard({
    required String title,
    required String currentUnit,
    required String lastTopic,
    required double progress,
    required List<String> levels,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text('다음 학습: $currentUnit', overflow: TextOverflow.ellipsis),
          Text('최근 학습: $lastTopic', overflow: TextOverflow.ellipsis),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: const Color(0xFFE0E0E0),
            color: const Color(0xFF4C89FF),
            minHeight: 8,
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '${(progress * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: levels.map((e) => Text(e, style: const TextStyle(fontSize: 12, color: Colors.grey))).toList(),
          )
        ],
      ),
    );
  }

  // ... (기존 _buildListCard 코드)
  Widget _buildListCard({
    required String title,
    required List<String> items,
    required String onMoreTapComment,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              GestureDetector(
                onTap: () {
                  debugPrint('게시판으로 이동 로직 필요: $onMoreTapComment');
                },
                child: const Row(
                  children: [
                    Text(
                      '게시판으로',
                      style: TextStyle(color: Colors.blue),
                    ),
                    SizedBox(width: 4),
                    Icon(Icons.arrow_forward_ios, size: 14, color: Colors.blue),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          for (var item in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Text(
                item,
                style: const TextStyle(fontSize: 14),
                overflow: TextOverflow.ellipsis,
              ),
            ),
        ],
      ),
    );
  }
}